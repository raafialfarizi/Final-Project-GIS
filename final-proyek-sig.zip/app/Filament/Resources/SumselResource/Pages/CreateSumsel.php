<?php

namespace App\Filament\Resources\SumselResource\Pages;

use App\Filament\Resources\SumselResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSumsel extends CreateRecord
{
    protected static string $resource = SumselResource::class;
}
